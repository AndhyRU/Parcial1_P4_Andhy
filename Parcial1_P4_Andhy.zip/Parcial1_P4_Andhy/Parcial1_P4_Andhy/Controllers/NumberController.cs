﻿using Microsoft.AspNetCore.Mvc;
using Parcial1_P4_Andhy.Models;
using Parcial1_P4_Andhy.Services;

namespace Parcial1_P4_Andhy.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class NumberController : ControllerBase
    {
        private readonly NumbersService _numbersService;

        public NumberController(NumbersService service)
        {
            _numbersService = service;
        }

        [HttpGet("{numero}")]
        public IActionResult Sumar(int numero)
        {
            int resultado = numero + numero;

            return Ok(resultado);
        }
    }
}
